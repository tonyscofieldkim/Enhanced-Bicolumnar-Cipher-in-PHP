# EBC (Enhanced Bicolunar Cipher)---Not actually a standard---but we can call it anything we want.

[meta_me]`@tony_Kimari`

[about_this](#about.html)

---- module
---
    ---This module implements the bicolumnar cipher for encrypting and decrypting text. I'm calling it enhanced because it is capable of using the whole of ASCII, not just the alphabet.
    ---
---

`usage` [You can do tests locally with XAMMP or any server package that supports php]

`Quick DEMO`
[usage](#index.html)
[backend](#ebc_demo.php)

![make sure you put the CLASS folder intact]

--- --- CLASS
--
    --- ebc.php 
    ---ebc_exceptions.php
    ---ebc_functions.php
---
--------------------------

***  
`use this in your code`
-- require("Path_to_CLASS_folder/ebc_functions.php")
---
***
